package com.google.booksapi.model.volumes.volume_sub_classes.volume;

import lombok.Data;

@Data
public class SearchInfo {
    private String textSnippet;
}
