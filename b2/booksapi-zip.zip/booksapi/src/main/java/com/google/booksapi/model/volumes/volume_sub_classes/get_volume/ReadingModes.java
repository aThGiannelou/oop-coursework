package com.google.booksapi.model.volumes.volume_sub_classes.get_volume;

import lombok.Data;

@Data
public class ReadingModes {
    private Boolean text;
    private Boolean image;
}
