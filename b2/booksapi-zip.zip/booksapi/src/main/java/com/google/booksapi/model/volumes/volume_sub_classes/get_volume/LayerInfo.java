package com.google.booksapi.model.volumes.volume_sub_classes.get_volume;

import lombok.Data;

import java.util.List;

@Data
public class LayerInfo {
    private List<Layer> layers;
}
